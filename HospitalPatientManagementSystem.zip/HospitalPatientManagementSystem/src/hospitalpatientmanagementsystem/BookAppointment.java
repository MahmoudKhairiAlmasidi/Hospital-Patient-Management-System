/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientmanagementsystem;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.derby.client.am.ResultSet;
/**
 *
 * @author mahmoudkalmasidi
 */
enum AppointmentStatus{
    PENDING,
    CONFIRMED,
    CANCELLED,
    COMPLETED
}
public class BookAppointment {
    private String appointmentID;
    private String date;
    private String time;
    private Doctor healthcareProvider;
    private Patient patient;
    private AppointmentStatus status;
    Connection conncat = null;
    java.sql.Statement stcat = null;
    ResultSet rs=null;

    public BookAppointment(String appointmentID, String date, String time, Doctor healthcareProvider, Patient patient, AppointmentStatus status) {
        this.appointmentID = appointmentID;
        this.date = date;
        this.time = time;
        this.healthcareProvider = healthcareProvider;
        this.patient = patient;
        this.status = status;
    }
    
    public BookAppointment(String appointmentID, String date, String time, AppointmentStatus status) {
        this.appointmentID = appointmentID;
        this.date = date;
        this.time = time;
        this.status = status;
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            String sql = "INSERT INTO BOOKAPPOINTMENT VALUES ('" + appointmentID + "', '" + date + "', '" + time + "', '" + status +  "')";

            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }   
        
    }
    
    public BookAppointment() {
        try {
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
        } catch (SQLException ex) {
            System.out.println("Database connection failed");
        }
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(String appointmentID) {
        this.appointmentID = appointmentID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Doctor getHealthcareProvider() {
        return healthcareProvider;
    }

    public void setHealthcareProvider(Doctor healthcareProvider) {
        this.healthcareProvider = healthcareProvider;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public AppointmentStatus getStatus() {
        return status;
    }

    public void setStatus(AppointmentStatus status) {
        this.status = status;
    }
    
    public void manageAppointment(String appointmentID, String date, String time, AppointmentStatus status){
        this.appointmentID = appointmentID;
        this.date = date;
        this.time = time;
        
        this.status = status;
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            
            String sql = "UPDATE BOOKAPPOINTMENT SET DATE ='" + date + "' , TIME ='" + time + "' , STATUS ='" + status + "' WHERE BOOKAPPOINTMENTID='" + appointmentID +"'";
            

            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }   
    }
    
    public void viewScheduledAppointment(){
        try {
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            String sql = "SELECT * FROM BOOKAPPOINTMENT";
            stcat = conncat.createStatement();
            rs = (ResultSet) stcat.executeQuery(sql);
            while(rs.next()){
            System.out.println(rs.getString("BOOKAPPOINTMENTID")+"\t"+rs.getString("TIME")+"\t"+rs.getString("DATE")+"\t"+rs.getString("STATUS"));
            }
            stcat.close();
            conncat.close();
            } catch (SQLException ex) {
            System.out.println(ex);
            }
    }
    
    public void cancelAppointment(String appointmentID){
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            String sql = "DELETE FROM BOOKAPPOINTMENT WHERE BOOKAPPOINTMENTID='" + appointmentID + "'";

            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        } 
    }
    
    public void getAppointmentDetails(){
        System.out.println("Appointment ID : " + appointmentID);
        System.out.println("Date : " + date);
        System.out.println("Time : " + time);
        System.out.println("Healthcare Provider : " + healthcareProvider);
        System.out.println("Status : " + status);
    }
}

