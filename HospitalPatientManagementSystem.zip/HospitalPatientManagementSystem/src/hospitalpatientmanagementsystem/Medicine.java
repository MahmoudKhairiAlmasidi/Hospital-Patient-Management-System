package hospitalpatientmanagementsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Mariam
 */
public class Medicine {
    private String name ;
    private String ID;
    private Patient patient;
    private Doctor doctor;
    private String dosageForm ;
    private String dosageStrength;

    public Medicine(String name,String dosageForm,String dosageStrength, String ID){
this.dosageForm = dosageForm;
this.dosageStrength = dosageStrength;
this.name = name;
this.ID=ID;
 }
    public void setName(String name){
        this.name=name;
    }
    public String getName() {
        return this.name;
    }
    
    public void setID(String ID){
        this.ID=ID;
    }
    public String getID() {
        return this.ID;
    }
 
    public void setPatient(Patient patient) {
        this.patient = patient;
    }
    
    
    public Patient getPatient() {
        return this.patient;
    }
    
   
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
    
    
    public Doctor getDoctor() {
        return this.doctor;
    }
    
    
    public void setDosageForm(String dosageForm) {
        this.dosageForm = dosageForm;
    }
    
    
    public String getDosageForm() {
        return this.dosageForm;
    }
    
   
    public void setDosageStrength(String dosageStrength) {
        this.dosageStrength = dosageStrength;
    }
    
  
    public String getDosageStrength() {
        return this.dosageStrength;
    }
    
   public String prescribeMedication() {
    if (patient == null ) {
        return "Cannot prescribe medication: Patient information missing.";
    } else {
        return "Medication prescribed for " + patient.getName() + ": " + name;
    }
}
    public void medicineInformation() {
        // Implementation for displaying medicine information
        System.out.println("Medicine Name: " + name);
        System.out.println("Dosage Form: " + dosageForm);
        System.out.println("Dosage Strength: " +dosageStrength);
        
    }
}

