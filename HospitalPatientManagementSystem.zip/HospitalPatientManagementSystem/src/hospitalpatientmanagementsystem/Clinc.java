package hospitalpatientmanagementsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
/**
 *
 * @author Mariam
 */
public class Clinc {
     private String name ;
    private String location ;
    private String phone;
    private ArrayList specialties = new ArrayList <String>();
    
    
    public Clinc(String name,String location){
        this.name=name;
        this.location=location;
        this.phone=phone;
       
    }
      
       
   public void setSpecialties(ArrayList specialties) {
        this.specialties = specialties;
    }
 public ArrayList getSpecialties() {
        return specialties;
    }
 
    public void setName(String name){
        this.name=name;
    }
    public String getName() {
        return this.name;
    }
    
  
    public void setLocation(String loctaion) {
        this.location = location;
    }
    
     public void addSpecialty(String specialty) {
        specialties.add(specialty);
    }
    
    
    public String getPhone() {
        return this.phone;
    }
    
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public void searchSpecialty() {
        
        System.out.println("Clinic selected: Location - " + location + ", Phone " + phone);
    }
    

    public void chooseClinic(String specialty) {
        // Implementation for searching for a specialty
        if (specialties.contains(specialty)) {
            System.out.println("Clinic " + name + " offers " + specialty + " services.");
        } else {
            System.out.println("Specialty not found in clinic " + name);
        }
    }
}
    
 
