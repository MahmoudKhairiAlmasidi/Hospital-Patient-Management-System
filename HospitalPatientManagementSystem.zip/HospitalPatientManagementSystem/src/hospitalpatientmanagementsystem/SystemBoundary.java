/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientmanagementsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class SystemBoundary {
    public void showLogin(){}
    public void showOpition(){}
    public void selectOpition(){}
    public void Login(){}
}
