/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author mahmoudkalmasidi
 */
public class Doctor {
    private String doctorID;
    private String name;
    private String specialty;
    Connection conncat = null;
    java.sql.Statement stcat = null;
    
    public Doctor(String doctorID, String name, String specialty) {
        this.doctorID = doctorID;
        this.name = name;
        this.specialty = specialty;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            String sql = "INSERT INTO DOCTOR VALUES ('" + doctorID + "', '" + name + "', '" + specialty + "')";
           
            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public String getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(String doctorID) {
        this.doctorID = doctorID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

}

