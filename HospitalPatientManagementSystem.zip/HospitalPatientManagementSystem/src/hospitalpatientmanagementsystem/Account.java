/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author mahmoudkalmasidi
 */
public class Account {
    private String username;
    private String password;
    static ArrayList Accounts = new ArrayList<Account>();
    Connection conncat = null;
    java.sql.Statement stcat = null;

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            String sql = "INSERT INTO ACCOUNT VALUES ('" + password + "', '" + username + "')";

            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
//    public Account() {
//        try {
//            conncat = DriverManager.getConnection("jdbc:derby:buee;create=true;","bue","bue");
//            stcat = conncat.createStatement();
//            System.out.println("Database connected successfully");
//        } catch (SQLException ex) {
//            System.out.println("Database connection failed");
//        }
//    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public static Account checkAccount (String name, String pass)
    {
        Account P = null;
        for (int i=0; i < Accounts.size(); i++)
        { 
            P = (Account) Accounts.get(i);
            if (P.getUsername().equals(name) && P.getPassword().equals(pass))
                return P;
        }
        return null;
    }
}

