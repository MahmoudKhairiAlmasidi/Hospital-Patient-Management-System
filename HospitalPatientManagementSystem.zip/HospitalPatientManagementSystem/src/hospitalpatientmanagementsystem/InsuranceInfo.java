/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author mahmoudkalmasidi
 */
public class InsuranceInfo {
    private String insuranceCompany;
    private String policyNumber;
    Connection conncat = null;
    java.sql.Statement stcat = null;
    
    public InsuranceInfo(String insuranceCompany, String policyNumber) {
        this.insuranceCompany = insuranceCompany;
        this.policyNumber = policyNumber;
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            String sql = "INSERT INTO INSURANCEINFO VALUES ('" + policyNumber + "', '" + insuranceCompany + "')";

            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
    }
    
//    public InsuranceInfo() {
//        try {
//            conncat = DriverManager.getConnection("jdbc:derby:buee;","bue","bue");
//            stcat = conncat.createStatement();
//            System.out.println("Database connected successfully");
//        } catch (SQLException ex) {
//            System.out.println("Database connection failed");
//        }
//    }

    public String getInsuranceCompany() {
        return insuranceCompany;
    }

    public void setInsuranceCompany(String insuranceCompany) {
        this.insuranceCompany = insuranceCompany;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
}

