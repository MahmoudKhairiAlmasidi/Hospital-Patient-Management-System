/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientmanagementsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class AppointmentControl {
    public void verifyLogin(){}
    public void viewSchedule(){}
    public void manageSchedule(){}
}
