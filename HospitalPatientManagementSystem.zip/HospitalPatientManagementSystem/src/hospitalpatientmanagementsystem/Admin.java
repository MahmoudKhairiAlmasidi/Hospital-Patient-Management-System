/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package hospitalpatientmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Administrator
 */
public class Admin {

    private String adminID;
    private String name;
    Connection conncat = null;
    java.sql.Statement stcat = null;
    
    public Admin(String adminID, String name) {
        this.adminID = adminID;
        this.name = name;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            String sql = "INSERT INTO ADMIN VALUES ('" + adminID + "', '" + name + "')";

            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
     public void setAdminId(String adminID) {
        this.adminID = adminID;
    }
     
    public String getAdminId() {
        return adminID;
    }

     public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
    

   
