/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;



/**
 *
 * @author mahmoudkalmasidi
 */
public class Patient {
    private String patientID;
    private String medicalHistory;
    private String name;
    private InsuranceInfo insuranceInfo;
    Connection conncat = null;
    java.sql.Statement stcat = null;

    public Patient(String patientID, String medicalHistory, String name, InsuranceInfo insuranceInfo) {
        this.patientID = patientID;
        this.medicalHistory = medicalHistory;
        this.name = name;
        this.insuranceInfo = insuranceInfo;
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            String sql = "INSERT INTO PATIENT VALUES ('" + patientID + "', '" + medicalHistory + "', '" + name + "', '" + insuranceInfo.getPolicyNumber() + "', '" + insuranceInfo.getInsuranceCompany() +"')";
           
            stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
    }

//    public Patient() {
//        try {
//            conncat = DriverManager.getConnection("jdbc:derby:buee;","bue","bue");
//            stcat = conncat.createStatement();
//            System.out.println("Database connected successfully");
//        } catch (SQLException ex) {
//            System.out.println("Database connection failed");
//        }
//     
//    }

    
    public String getPatientID() {
        return patientID;
    }

    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }

    public String getMedicalHistory() {
        return medicalHistory;
    }

    public void setMedicalHistory(String medicalHistory) {
        this.medicalHistory = medicalHistory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public InsuranceInfo getInsuranceInfo() {
        return insuranceInfo;
    }

    public void setInsuranceInfo(InsuranceInfo insuranceInfo) {
        this.insuranceInfo = insuranceInfo;
    }
    
    
}

