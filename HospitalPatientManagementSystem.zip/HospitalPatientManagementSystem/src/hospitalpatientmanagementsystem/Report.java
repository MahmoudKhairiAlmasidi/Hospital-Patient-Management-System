/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package hospitalpatientmanagementsystem;

import java.sql.DriverManager;
import org.apache.derby.client.am.Connection;


public class Report {
   
    private Patient patient;
    //private Nurse nurse;
    private BookAppointment appointment;
    private Doctor doctor;
    private String date;
    private String title;
    Connection conncat = null;
    java.sql.Statement stcat = null;

   
    public Report(String pname, String nName, String appointmentID, String date, String title) {
        this.date = date;
        this.title = title;
         try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            conncat = (Connection) DriverManager.getConnection("jdbc:derby://localhost:1527/HospitalPatientManagementSystem","Mahmoud","1234");
            stcat = conncat.createStatement();
            System.out.println("Database connected successfully");
            //String sql = "INSERT INTO REPORT VALUES ('" + patientID + "', '" + medicalHistory + "', '" + name + "', '" + insuranceInfo.getPolicyNumber() + "', '" + insuranceInfo.getInsuranceCompany() +"')";
           
            //stcat.executeUpdate(sql);
            stcat.close();
            conncat.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void setDate(String date) {
        this.date = date;
    }
     public void settitle(String title) {
        this.title = title;
    }
    public String getDate() {
        return date;
    }
    
   public String gettitle() {
        return title;
    }

   

    
    public String generatePatientReport() {
        return "Patient Information:\n" + patient.toString();
    }

//    public String generateNurseReport() {
//        return "Nurse Information:\n" + nurse.toString();
//     }
    public String generatedoctorReport() {
        return "Doctor Information:\n" + doctor.toString();
    }

    public String generateAppointmentReport() {
        return "Appointment Information:\n" + appointment.toString();
    }
     public String generateReport() {
        String report = "Report Title: " + title + "\n";
        report += "Date: " + date + "\n\n";
        report += generatePatientReport() + "\n";
        //report += generateNurseReport() + "\n";
        report += generateAppointmentReport() + "\n";
        report += generatedoctorReport() + "\n";
        return report;
    }
//      public static void main(String[] args) {
//       
//        Patient patient = new Patient("2356", "lung cancer", "mirna ibrahim","A");
//        Nurse nurse = new Nurse("538", "Rofida", "ICU");
//        BookAppointment appointment = new BookAppointment("126", "2024-05-06", "10:00 AM","Dr.Khaled Shawky","mirna ibrahim","confirmed");
//
//       
//        Report report = new Report(patient, nurse, appointment, "2024-05-06", "Medical Report");
//        System.out.println(report.generateReport());
//    }
}
