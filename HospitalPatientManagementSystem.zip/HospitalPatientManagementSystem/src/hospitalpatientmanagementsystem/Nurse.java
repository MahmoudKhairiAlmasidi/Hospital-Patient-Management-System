/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package hospitalpatientmanagementsystem;

/**
 *
 * @author USER
 */
public class Nurse {
 
    private int nurseId;
    private String name;
    private String specialization;

 
    public Nurse(int nurseId, String name, String specialization) {
        this.nurseId = nurseId;
        this.name = name;
        this.specialization = specialization;
    }
        public int getNurseId() {
        return nurseId;
    }

    public void setNurseId(int nurseId) {
        this.nurseId = nurseId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }
     public void patientAssignment(Patient patient) {
        System.out.println("Assigning patient " + patient.getName() + " to Nurse " + this.name);
    }
    
}
